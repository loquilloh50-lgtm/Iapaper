package com.example.aiwallpapers

import android.app.WallpaperManager
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Target(val label: String, val flags: Int) {
    HOME("Inicio", WallpaperManager.FLAG_SYSTEM),
    LOCK("Bloqueo", WallpaperManager.FLAG_LOCK),
    BOTH("Ambas", WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
}

@Composable
fun WallpaperScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var shown by remember { mutableStateOf<Bitmap?>(null) }
    var style by remember { mutableStateOf(FilterStyle.ORIGINAL) }
    var target by remember { mutableStateOf(Target.BOTH) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val bmp = runCatching { WallpaperUtils.load(context, uri) }.getOrNull()
            original = bmp
            shown = bmp
            style = FilterStyle.ORIGINAL
            busy = false
            if (bmp == null) snackbar.showSnackbar("No se pudo abrir la imagen")
        }
    }

    fun selectStyle(s: FilterStyle) {
        val src = original ?: return
        style = s
        scope.launch {
            busy = true
            shown = runCatching {
                withContext(Dispatchers.Default) { Filters.apply(src, s) }
            }.getOrElse { src }
            busy = false
        }
    }

    val dm = context.resources.displayMetrics
    val screenRatio = dm.widthPixels.toFloat() / dm.heightPixels

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AI Wallpapers", style = MaterialTheme.typography.headlineSmall)

            Box(
                modifier = Modifier
                    .weight(1f)
                    .aspectRatio(screenRatio)
                    .clip(RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                val bmp = shown
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Vista previa",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("Elige una foto para empezar")
                        }
                    }
                }
                if (busy) CircularProgressIndicator()
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(FilterStyle.entries.toList()) { s ->
                    FilterChip(
                        selected = style == s,
                        enabled = original != null && !busy,
                        onClick = { selectStyle(s) },
                        label = { Text(s.label) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Target.entries.forEach { t ->
                    FilterChip(
                        selected = target == t,
                        onClick = { target = t },
                        label = { Text(t.label) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Galería")
                }
                Button(
                    enabled = shown != null && !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            val ok = runCatching {
                                WallpaperUtils.apply(context, shown!!, target.flags)
                            }.isSuccess
                            busy = false
                            snackbar.showSnackbar(if (ok) "¡Fondo aplicado!" else "No se pudo aplicar")
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Wallpaper, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Aplicar")
                }
            }
        }
    }
}
