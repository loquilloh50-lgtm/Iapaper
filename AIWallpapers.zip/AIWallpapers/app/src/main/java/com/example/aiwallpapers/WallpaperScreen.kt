package com.example.aiwallpapers

import android.app.WallpaperManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private enum class Target(val label: String, val flags: Int) {
    HOME("Inicio", WallpaperManager.FLAG_SYSTEM),
    LOCK("Bloqueo", WallpaperManager.FLAG_LOCK),
    BOTH("Ambas", WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
}

@Composable
fun WallpaperScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var bitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var target by remember { mutableStateOf(Target.BOTH) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            bitmap = runCatching { WallpaperUtils.load(context, uri) }.getOrNull()
            busy = false
            if (bitmap == null) snackbar.showSnackbar("No se pudo abrir la imagen")
        }
    }

    val dm = context.resources.displayMetrics
    val screenRatio = dm.widthPixels.toFloat() / dm.heightPixels

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AI Wallpapers", style = MaterialTheme.typography.headlineSmall)

            Box(
                modifier = Modifier
                    .weight(1f)
                    .aspectRatio(screenRatio)
                    .clip(RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                val bmp = bitmap
                when {
                    busy -> CircularProgressIndicator()
                    bmp != null -> Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Vista previa",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    else -> Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("Elige una foto para empezar")
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Target.entries.forEach { t ->
                    FilterChip(
                        selected = target == t,
                        onClick = { target = t },
                        label = { Text(t.label) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Galería")
                }
                Button(
                    enabled = bitmap != null && !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            val ok = runCatching {
                                WallpaperUtils.apply(context, bitmap!!, target.flags)
                            }.isSuccess
                            busy = false
                            snackbar.showSnackbar(if (ok) "¡Fondo aplicado!" else "No se pudo aplicar")
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Wallpaper, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Aplicar")
                }
            }
        }
    }
}
