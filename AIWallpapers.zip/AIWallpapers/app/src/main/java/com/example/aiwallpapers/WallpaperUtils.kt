package com.example.aiwallpapers

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object WallpaperUtils {

    /** Carga la imagen limitando su tamaño para no agotar la memoria. */
    suspend fun load(context: Context, uri: Uri, maxSide: Int = 3000): Bitmap =
        withContext(Dispatchers.IO) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val longest = maxOf(w, h)
                if (longest > maxSide) {
                    val f = maxSide.toFloat() / longest
                    decoder.setTargetSize((w * f).toInt(), (h * f).toInt())
                }
            }
        }

    /** Recorta al centro con la misma proporción que la pantalla. */
    fun cropToRatio(src: Bitmap, ratio: Float): Bitmap {
        val srcRatio = src.width.toFloat() / src.height
        val (w, h) = if (srcRatio > ratio) {
            (src.height * ratio).toInt() to src.height
        } else {
            src.width to (src.width / ratio).toInt()
        }
        val x = (src.width - w) / 2
        val y = (src.height - h) / 2
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    /** Aplica el bitmap como fondo. [flags] = FLAG_SYSTEM, FLAG_LOCK o ambos. */
    suspend fun apply(context: Context, bitmap: Bitmap, flags: Int) =
        withContext(Dispatchers.IO) {
            val dm = context.resources.displayMetrics
            val cropped = cropToRatio(bitmap, dm.widthPixels.toFloat() / dm.heightPixels)
            WallpaperManager.getInstance(context).setBitmap(cropped, null, true, flags)
        }
}
