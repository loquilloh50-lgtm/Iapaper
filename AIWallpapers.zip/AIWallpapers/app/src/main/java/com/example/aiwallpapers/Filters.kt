package com.example.aiwallpapers

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class FilterStyle(val label: String) {
    ORIGINAL("Original"), NEON("Neón"), ANIME("Anime"), OIL("Óleo"),
    SKETCH("Lápiz"), VINTAGE("Vintage"), CYBER("Cyberpunk"), POP("Pop art"),
    VICE("Vice City"), MAGAZINE("Revista antigua"), GOTHIC("Gótico"), NOIR("Noir"),
    GLITCH("Glitch"), SUNSET("Atardecer"), PIXEL("Pixel"), WATERCOLOR("Acuarela"),
    VHS("VHS"), DREAM("Ensueño")
}

/** Filtros 100% en el dispositivo, sin internet ni modelos descargados. */
object Filters {
    private const val MAX_SIDE = 2000

    fun apply(src: Bitmap, style: FilterStyle): Bitmap {
        if (style == FilterStyle.ORIGINAL) return src
        val bmp = downscale(src)
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = when (style) {
            FilterStyle.NEON -> neon(px, w, h)
            FilterStyle.ANIME -> anime(px, w, h)
            FilterStyle.OIL -> oil(px, w, h)
            FilterStyle.SKETCH -> sketch(px, w, h)
            FilterStyle.VINTAGE -> vintage(px)
            FilterStyle.CYBER -> cyber(px)
            FilterStyle.POP -> pop(px)
            FilterStyle.VICE -> vice(px)
            FilterStyle.MAGAZINE -> magazine(px, w, h)
            FilterStyle.GOTHIC -> gothic(px, w, h)
            FilterStyle.NOIR -> noir(px, w, h)
            FilterStyle.GLITCH -> glitch(px, w, h)
            FilterStyle.SUNSET -> sunset(px, w, h)
            FilterStyle.PIXEL -> pixel(px, w, h)
            FilterStyle.WATERCOLOR -> watercolor(px, w, h)
            FilterStyle.VHS -> vhs(px, w, h)
            FilterStyle.DREAM -> dream(px, w, h)
            FilterStyle.ORIGINAL -> px
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- utilidades ----------
    private fun downscale(b: Bitmap): Bitmap {
        val longest = max(b.width, b.height)
        if (longest <= MAX_SIDE) return b
        val f = MAX_SIDE.toFloat() / longest
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    private fun r(p: Int) = (p shr 16) and 255
    private fun g(p: Int) = (p shr 8) and 255
    private fun b(p: Int) = p and 255
    private fun c(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v
    private fun pack(r: Int, g: Int, b: Int) = (255 shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b)
    private fun luma(p: Int) = (r(p) * 299 + g(p) * 587 + b(p) * 114) / 1000
    private fun lerp(a: Int, b: Int, t: Float) = (a + (b - a) * t).toInt()

    private fun saturate(p: Int, s: Float): Int {
        val l = luma(p)
        return pack(
            (l + (r(p) - l) * s).toInt(),
            (l + (g(p) - l) * s).toInt(),
            (l + (b(p) - l) * s).toInt()
        )
    }

    private fun boxBlur(src: IntArray, w: Int, h: Int, rad: Int): IntArray {
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        val d = 2 * rad + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (x in -rad..rad) sum += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                sum += src[row + min(x + rad + 1, w - 1)] - src[row + max(x - rad, 0)]
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (y in -rad..rad) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / d
                sum += tmp[min(y + rad + 1, h - 1) * w + x] - tmp[max(y - rad, 0) * w + x]
            }
        }
        return out
    }

    private fun blurColor(px: IntArray, w: Int, h: Int, rad: Int): IntArray {
        val rr = boxBlur(IntArray(px.size) { r(px[it]) }, w, h, rad)
        val gg = boxBlur(IntArray(px.size) { g(px[it]) }, w, h, rad)
        val bb = boxBlur(IntArray(px.size) { b(px[it]) }, w, h, rad)
        return IntArray(px.size) { pack(rr[it], gg[it], bb[it]) }
    }

    private fun edges(gray: IntArray, w: Int, h: Int): IntArray {
        val e = IntArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -gray[i - w - 1] + gray[i - w + 1] - 2 * gray[i - 1] + 2 * gray[i + 1] -
                gray[i + w - 1] + gray[i + w + 1]
            val gy = -gray[i - w - 1] - 2 * gray[i - w] - gray[i - w + 1] +
                gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1]
            e[i] = min(255, (abs(gx) + abs(gy)) / 2)
        }
        return e
    }

    private fun posterize(v: Int, levels: Int): Int {
        val step = 255f / (levels - 1)
        return (Math.round(v / step) * step).toInt()
    }

    // ---------- filtros ----------
    private fun neon(px: IntArray, w: Int, h: Int): IntArray {
        val gray = IntArray(px.size) { luma(px[it]) }
        val e = edges(boxBlur(gray, w, h, 1), w, h)
        val glow = boxBlur(e, w, h, 5)
        return IntArray(px.size) {
            val p = saturate(px[it], 2f)
            val m = max(1, max(r(p), max(g(p), b(p))))
            val k = 255f / m
            val strength = min(1f, (e[it] * 1.6f + glow[it] * 2.2f) / 255f)
            pack(
                (r(p) * 0.18f + r(p) * k * strength).toInt(),
                (g(p) * 0.18f + g(p) * k * strength).toInt(),
                (b(p) * 0.18f + b(p) * k * strength).toInt()
            )
        }
    }

    private fun anime(px: IntArray, w: Int, h: Int): IntArray {
        val smooth = blurColor(blurColor(px, w, h, 2), w, h, 2)
        val e = edges(IntArray(px.size) { luma(smooth[it]) }, w, h)
        return IntArray(px.size) {
            val p = saturate(smooth[it], 1.5f)
            if (e[it] > 40) pack(20, 20, 30)
            else pack(posterize(r(p), 6), posterize(g(p), 6), posterize(b(p), 6))
        }
    }

    private fun oil(px: IntArray, w: Int, h: Int, radius: Int = 3, levels: Int = 20): IntArray {
        val out = IntArray(w * h)
        val cnt = IntArray(levels)
        val sr = IntArray(levels)
        val sg = IntArray(levels)
        val sb = IntArray(levels)
        for (y in 0 until h) for (x in 0 until w) {
            cnt.fill(0); sr.fill(0); sg.fill(0); sb.fill(0)
            for (dy in -radius..radius) {
                val yy = (y + dy).coerceIn(0, h - 1)
                for (dx in -radius..radius) {
                    val p = px[yy * w + (x + dx).coerceIn(0, w - 1)]
                    val li = min(levels - 1, (r(p) + g(p) + b(p)) / 3 * levels / 256)
                    cnt[li]++; sr[li] += r(p); sg[li] += g(p); sb[li] += b(p)
                }
            }
            var m = 0
            for (i in 1 until levels) if (cnt[i] > cnt[m]) m = i
            out[y * w + x] = pack(sr[m] / cnt[m], sg[m] / cnt[m], sb[m] / cnt[m])
        }
        return out
    }

    private fun sketch(px: IntArray, w: Int, h: Int): IntArray {
        val gray = IntArray(px.size) { luma(px[it]) }
        val blur = boxBlur(IntArray(px.size) { 255 - gray[it] }, w, h, 8)
        return IntArray(px.size) {
            val v = c(gray[it] * 255 / max(1, 255 - blur[it]))
            pack(v, v, v)
        }
    }

    private fun vintage(px: IntArray) = IntArray(px.size) {
        val p = px[it]
        val rr = r(p); val gg = g(p); val bb = b(p)
        pack(
            (rr * 0.393f + gg * 0.769f + bb * 0.189f).toInt() + 15,
            (rr * 0.349f + gg * 0.686f + bb * 0.168f).toInt() + 10,
            (rr * 0.272f + gg * 0.534f + bb * 0.131f).toInt() + 20
        )
    }

    private fun cyber(px: IntArray) = IntArray(px.size) {
        val p = px[it]
        val t = luma(p) / 255f
        val s = saturate(p, 1.6f)
        pack(
            lerp(60, 0, t) / 2 + r(s) / 3 + (if (t < 0.5f) 50 else 0),
            lerp(0, 240, t) / 2 + g(s) / 3,
            lerp(110, 230, t) / 2 + b(s) / 3 + 30
        )
    }

    private fun pop(px: IntArray) = IntArray(px.size) {
        val p = saturate(px[it], 1.8f)
        pack(posterize(r(p), 4), posterize(g(p), 4), posterize(b(p), 4))
    }

    // ---------- 10 filtros nuevos ----------
    private fun vig(i: Int, w: Int, h: Int, s: Float): Float {
        val dx = ((i % w) - w / 2f) / (w / 2f)
        val dy = ((i / w) - h / 2f) / (h / 2f)
        return 1f - s * (dx * dx + dy * dy) / 2f
    }

    private fun contrast(v: Int, k: Float, off: Int = 0) = c(((v - 128) * k + 128).toInt() + off)

    private fun vice(px: IntArray) = IntArray(px.size) {
        val p = saturate(px[it], 1.5f)
        val t = luma(px[it]) / 255f
        val gr: Int
        val gg: Int
        val gb: Int
        if (t < 0.5f) {
            val k = t * 2
            gr = lerp(30, 255, k); gg = lerp(0, 40, k); gb = lerp(80, 160, k)
        } else {
            val k = (t - 0.5f) * 2
            gr = lerp(255, 120, k); gg = lerp(40, 240, k); gb = lerp(160, 255, k)
        }
        pack(
            (gr * 0.7f + r(p) * 0.3f).toInt(),
            (gg * 0.7f + g(p) * 0.3f).toInt(),
            (gb * 0.7f + b(p) * 0.3f).toInt()
        )
    }

    private fun magazine(px: IntArray, w: Int, h: Int): IntArray {
        val rnd = java.util.Random(7)
        return IntArray(px.size) { i ->
            val p = saturate(px[i], 0.5f)
            val grain = rnd.nextInt(19) - 9
            val v = vig(i, w, h, 0.5f)
            val dot = if ((i % w) % 4 == 0 && (i / w) % 4 == 0) 0.88f else 1f
            pack(
                (((28 + r(p) * 0.82f) * 246f / 255f + grain) * v * dot).toInt(),
                (((26 + g(p) * 0.80f) * 236f / 255f + grain) * v * dot).toInt(),
                (((22 + b(p) * 0.78f) * 205f / 255f + grain) * v * dot).toInt()
            )
        }
    }

    private fun gothic(px: IntArray, w: Int, h: Int) = IntArray(px.size) { i ->
        val p = saturate(px[i], 0.35f)
        val v = vig(i, w, h, 0.9f).coerceAtLeast(0f)
        val o = px[i]
        val redBoost = max(0, r(o) - (g(o) + b(o)) / 2)
        pack(
            (contrast(r(p), 1.4f, -30) * 0.9f * v + redBoost * 0.6f * v).toInt(),
            (contrast(g(p), 1.4f, -35) * 0.85f * v).toInt(),
            (contrast(b(p), 1.4f, -15) * 1.1f * v + 6).toInt()
        )
    }

    private fun noir(px: IntArray, w: Int, h: Int): IntArray {
        val rnd = java.util.Random(11)
        return IntArray(px.size) { i ->
            val l = contrast(luma(px[i]), 1.5f, -8)
            val n = rnd.nextInt(25) - 12
            val v = c(((l + n) * vig(i, w, h, 0.55f)).toInt())
            pack(v, v, v)
        }
    }

    private fun glitch(px: IntArray, w: Int, h: Int): IntArray {
        val rnd = java.util.Random(3)
        val shift = max(4, w / 120)
        val rowOff = IntArray(h)
        var y = 0
        while (y < h) {
            val bh = 5 + rnd.nextInt(max(6, h / 25))
            val off = if (rnd.nextInt(4) == 0) rnd.nextInt(max(2, w / 6)) - w / 12 else 0
            for (k in y until min(h, y + bh)) rowOff[k] = off
            y += bh
        }
        val out = IntArray(px.size)
        for (yy in 0 until h) for (x in 0 until w) {
            val row = yy * w
            val ox = rowOff[yy] + x
            val rr = r(px[row + (ox + shift).coerceIn(0, w - 1)])
            val gg = g(px[row + ox.coerceIn(0, w - 1)])
            val bb = b(px[row + (ox - shift).coerceIn(0, w - 1)])
            val dim = if (yy % 4 == 0) 0.85f else 1f
            out[row + x] = pack((rr * dim).toInt(), (gg * dim).toInt(), (bb * dim).toInt())
        }
        return out
    }

    private fun sunset(px: IntArray, w: Int, h: Int) = IntArray(px.size) { i ->
        val p = saturate(px[i], 1.3f)
        val f = (i / w).toFloat() / h
        pack(
            (r(p) * 1.15f + 25 + f * 25).toInt(),
            (g(p) * 0.88f + 8).toInt(),
            (b(p) * 0.72f + (1f - f) * 45).toInt()
        )
    }

    private fun pixel(px: IntArray, w: Int, h: Int): IntArray {
        val block = max(4, w / 80)
        val out = IntArray(px.size)
        var by = 0
        while (by < h) {
            val bh = min(block, h - by)
            var bx = 0
            while (bx < w) {
                val bw = min(block, w - bx)
                var sr = 0
                var sg = 0
                var sb = 0
                for (yy in by until by + bh) for (xx in bx until bx + bw) {
                    val p = px[yy * w + xx]
                    sr += r(p); sg += g(p); sb += b(p)
                }
                val n = bw * bh
                val col = saturate(
                    pack(posterize(sr / n, 7), posterize(sg / n, 7), posterize(sb / n, 7)), 1.3f
                )
                for (yy in by until by + bh) for (xx in bx until bx + bw) out[yy * w + xx] = col
                bx += block
            }
            by += block
        }
        return out
    }

    private fun watercolor(px: IntArray, w: Int, h: Int): IntArray {
        val sm = blurColor(blurColor(px, w, h, 3), w, h, 2)
        val e = edges(IntArray(px.size) { luma(sm[it]) }, w, h)
        val rnd = java.util.Random(5)
        return IntArray(px.size) { i ->
            val p = saturate(sm[i], 1.2f)
            val dark = 1f - min(0.35f, e[i] / 255f * 1.2f)
            val n = rnd.nextInt(9) - 4
            fun f(v: Int): Int = (((posterize(v, 10) * 0.6f + v * 0.4f) * 0.8f + 255 * 0.2f) * dark + n).toInt()
            pack(f(r(p)), f(g(p)), f(b(p)))
        }
    }

    private fun vhs(px: IntArray, w: Int, h: Int): IntArray {
        val rnd = java.util.Random(9)
        val shift = max(3, w / 150)
        val bandStart = (h * 0.72f).toInt()
        val bandEnd = bandStart + max(6, h / 60)
        return IntArray(px.size) { i ->
            val x = i % w
            val y = i / w
            val ox = if (y in bandStart..bandEnd) x + w / 30 else x
            val row = y * w
            val rr = r(px[row + (ox + shift).coerceIn(0, w - 1)])
            val gg = g(px[row + ox.coerceIn(0, w - 1)])
            val bb = b(px[row + (ox - shift).coerceIn(0, w - 1)])
            val dim = if (y % 4 < 2) 0.82f else 1.05f
            val n = rnd.nextInt(25) - 12
            val s = saturate(pack(rr, gg, bb), 0.85f)
            pack((r(s) * dim + n).toInt(), (g(s) * dim + n).toInt(), (b(s) * dim + n).toInt())
        }
    }

    private fun dream(px: IntArray, w: Int, h: Int): IntArray {
        val bright = IntArray(px.size) {
            val p = px[it]
            pack(max(0, r(p) - 110) * 2, max(0, g(p) - 110) * 2, max(0, b(p) - 110) * 2)
        }
        val bloom = blurColor(blurColor(bright, w, h, 12), w, h, 8)
        fun screen(a: Float, other: Int): Int = (255 - (255 - a) * (255 - other) / 255).toInt()
        return IntArray(px.size) {
            val p = saturate(px[it], 0.85f)
            pack(
                screen(r(p) * 0.85f + 46, r(bloom[it])),
                screen(g(p) * 0.85f + 38, g(bloom[it])),
                screen(b(p) * 0.85f + 54, b(bloom[it]))
            )
        }
    }
}
