package com.example.aiwallpapers

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class FilterStyle(val label: String) {
    ORIGINAL("Original"), NEON("Neón"), ANIME("Anime"), OIL("Óleo"),
    SKETCH("Lápiz"), VINTAGE("Vintage"), CYBER("Cyberpunk"), POP("Pop art")
}

/** Filtros 100% en el dispositivo, sin internet ni modelos descargados. */
object Filters {
    private const val MAX_SIDE = 2000

    fun apply(src: Bitmap, style: FilterStyle): Bitmap {
        if (style == FilterStyle.ORIGINAL) return src
        val bmp = downscale(src)
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = when (style) {
            FilterStyle.NEON -> neon(px, w, h)
            FilterStyle.ANIME -> anime(px, w, h)
            FilterStyle.OIL -> oil(px, w, h)
            FilterStyle.SKETCH -> sketch(px, w, h)
            FilterStyle.VINTAGE -> vintage(px)
            FilterStyle.CYBER -> cyber(px)
            FilterStyle.POP -> pop(px)
            FilterStyle.ORIGINAL -> px
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- utilidades ----------
    private fun downscale(b: Bitmap): Bitmap {
        val longest = max(b.width, b.height)
        if (longest <= MAX_SIDE) return b
        val f = MAX_SIDE.toFloat() / longest
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    private fun r(p: Int) = (p shr 16) and 255
    private fun g(p: Int) = (p shr 8) and 255
    private fun b(p: Int) = p and 255
    private fun c(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v
    private fun pack(r: Int, g: Int, b: Int) = (255 shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b)
    private fun luma(p: Int) = (r(p) * 299 + g(p) * 587 + b(p) * 114) / 1000
    private fun lerp(a: Int, b: Int, t: Float) = (a + (b - a) * t).toInt()

    private fun saturate(p: Int, s: Float): Int {
        val l = luma(p)
        return pack(
            (l + (r(p) - l) * s).toInt(),
            (l + (g(p) - l) * s).toInt(),
            (l + (b(p) - l) * s).toInt()
        )
    }

    private fun boxBlur(src: IntArray, w: Int, h: Int, rad: Int): IntArray {
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        val d = 2 * rad + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (x in -rad..rad) sum += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                sum += src[row + min(x + rad + 1, w - 1)] - src[row + max(x - rad, 0)]
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (y in -rad..rad) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / d
                sum += tmp[min(y + rad + 1, h - 1) * w + x] - tmp[max(y - rad, 0) * w + x]
            }
        }
        return out
    }

    private fun blurColor(px: IntArray, w: Int, h: Int, rad: Int): IntArray {
        val rr = boxBlur(IntArray(px.size) { r(px[it]) }, w, h, rad)
        val gg = boxBlur(IntArray(px.size) { g(px[it]) }, w, h, rad)
        val bb = boxBlur(IntArray(px.size) { b(px[it]) }, w, h, rad)
        return IntArray(px.size) { pack(rr[it], gg[it], bb[it]) }
    }

    private fun edges(gray: IntArray, w: Int, h: Int): IntArray {
        val e = IntArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -gray[i - w - 1] + gray[i - w + 1] - 2 * gray[i - 1] + 2 * gray[i + 1] -
                gray[i + w - 1] + gray[i + w + 1]
            val gy = -gray[i - w - 1] - 2 * gray[i - w] - gray[i - w + 1] +
                gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1]
            e[i] = min(255, (abs(gx) + abs(gy)) / 2)
        }
        return e
    }

    private fun posterize(v: Int, levels: Int): Int {
        val step = 255f / (levels - 1)
        return (Math.round(v / step) * step).toInt()
    }

    // ---------- filtros ----------
    private fun neon(px: IntArray, w: Int, h: Int): IntArray {
        val gray = IntArray(px.size) { luma(px[it]) }
        val e = edges(boxBlur(gray, w, h, 1), w, h)
        val glow = boxBlur(e, w, h, 5)
        return IntArray(px.size) {
            val p = saturate(px[it], 2f)
            val m = max(1, max(r(p), max(g(p), b(p))))
            val k = 255f / m
            val strength = min(1f, (e[it] * 1.6f + glow[it] * 2.2f) / 255f)
            pack(
                (r(p) * 0.18f + r(p) * k * strength).toInt(),
                (g(p) * 0.18f + g(p) * k * strength).toInt(),
                (b(p) * 0.18f + b(p) * k * strength).toInt()
            )
        }
    }

    private fun anime(px: IntArray, w: Int, h: Int): IntArray {
        val smooth = blurColor(blurColor(px, w, h, 2), w, h, 2)
        val e = edges(IntArray(px.size) { luma(smooth[it]) }, w, h)
        return IntArray(px.size) {
            val p = saturate(smooth[it], 1.5f)
            if (e[it] > 40) pack(20, 20, 30)
            else pack(posterize(r(p), 6), posterize(g(p), 6), posterize(b(p), 6))
        }
    }

    private fun oil(px: IntArray, w: Int, h: Int, radius: Int = 3, levels: Int = 20): IntArray {
        val out = IntArray(w * h)
        val cnt = IntArray(levels)
        val sr = IntArray(levels)
        val sg = IntArray(levels)
        val sb = IntArray(levels)
        for (y in 0 until h) for (x in 0 until w) {
            cnt.fill(0); sr.fill(0); sg.fill(0); sb.fill(0)
            for (dy in -radius..radius) {
                val yy = (y + dy).coerceIn(0, h - 1)
                for (dx in -radius..radius) {
                    val p = px[yy * w + (x + dx).coerceIn(0, w - 1)]
                    val li = min(levels - 1, (r(p) + g(p) + b(p)) / 3 * levels / 256)
                    cnt[li]++; sr[li] += r(p); sg[li] += g(p); sb[li] += b(p)
                }
            }
            var m = 0
            for (i in 1 until levels) if (cnt[i] > cnt[m]) m = i
            out[y * w + x] = pack(sr[m] / cnt[m], sg[m] / cnt[m], sb[m] / cnt[m])
        }
        return out
    }

    private fun sketch(px: IntArray, w: Int, h: Int): IntArray {
        val gray = IntArray(px.size) { luma(px[it]) }
        val blur = boxBlur(IntArray(px.size) { 255 - gray[it] }, w, h, 8)
        return IntArray(px.size) {
            val v = c(gray[it] * 255 / max(1, 255 - blur[it]))
            pack(v, v, v)
        }
    }

    private fun vintage(px: IntArray) = IntArray(px.size) {
        val p = px[it]
        val rr = r(p); val gg = g(p); val bb = b(p)
        pack(
            (rr * 0.393f + gg * 0.769f + bb * 0.189f).toInt() + 15,
            (rr * 0.349f + gg * 0.686f + bb * 0.168f).toInt() + 10,
            (rr * 0.272f + gg * 0.534f + bb * 0.131f).toInt() + 20
        )
    }

    private fun cyber(px: IntArray) = IntArray(px.size) {
        val p = px[it]
        val t = luma(p) / 255f
        val s = saturate(p, 1.6f)
        pack(
            lerp(60, 0, t) / 2 + r(s) / 3 + (if (t < 0.5f) 50 else 0),
            lerp(0, 240, t) / 2 + g(s) / 3,
            lerp(110, 230, t) / 2 + b(s) / 3 + 30
        )
    }

    private fun pop(px: IntArray) = IntArray(px.size) {
        val p = saturate(px[it], 1.8f)
        pack(posterize(r(p), 4), posterize(g(p), 4), posterize(b(p), 4))
    }
}
