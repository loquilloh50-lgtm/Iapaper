# AI Wallpapers (fase 2: filtros)

1. Abre la carpeta en Android Studio (Koala o más reciente) y espera el Gradle Sync.
   Si falta el wrapper: Android Studio lo genera, o ejecuta `gradle wrapper`.
2. Ejecuta en un emulador o móvil con Android 9+ (API 28).

Incluye: selector de galería, vista previa con la proporción de tu pantalla,
recorte automático y aplicar como fondo (inicio / bloqueo / ambas).

Siguiente fase: quitar fondo y filtros con IA en el dispositivo.
